package com.karthik;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OtmMappingApplicationTests {

	@Test
	void contextLoads() {
	}

}
